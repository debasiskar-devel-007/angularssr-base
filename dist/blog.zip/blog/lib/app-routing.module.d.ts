export declare class AppRoutingModule {
}
