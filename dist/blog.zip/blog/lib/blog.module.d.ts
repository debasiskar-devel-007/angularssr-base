export declare class BlogModule {
}
