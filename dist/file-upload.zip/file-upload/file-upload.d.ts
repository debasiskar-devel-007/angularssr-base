/**
 * Generated bundle index. Do not edit.
 */
export * from './projects';
export { MaterialModule as ɵe } from './lib/Module/material-module';
export { AlertMessageComponent as ɵb } from './lib/component/alert-message/alert-message.component';
export { DialogBoxComponent as ɵc } from './lib/component/dialog-box/dialog-box.component';
export { PreviewFilesComponent as ɵd } from './lib/component/preview-files/preview-files.component';
export { DragDropDirective as ɵa } from './lib/directive/drag-drop.directive';
