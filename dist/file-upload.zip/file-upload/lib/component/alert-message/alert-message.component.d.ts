import { OnInit } from '@angular/core';
export declare class AlertMessageComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
