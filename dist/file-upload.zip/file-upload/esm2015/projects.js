/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of file-upload
 */
export { FileUploadService } from './lib/file-upload.service';
export { FileUploadComponent } from './lib/file-upload.component';
export { FileUploadModule } from './lib/file-upload.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvamVjdHMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9maWxlLXVwbG9hZC8iLCJzb3VyY2VzIjpbInByb2plY3RzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxrQ0FBYywyQkFBMkIsQ0FBQztBQUMxQyxvQ0FBYyw2QkFBNkIsQ0FBQztBQUM1QyxpQ0FBYywwQkFBMEIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgZmlsZS11cGxvYWRcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9maWxlLXVwbG9hZC5zZXJ2aWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2ZpbGUtdXBsb2FkLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9maWxlLXVwbG9hZC5tb2R1bGUnO1xuIl19