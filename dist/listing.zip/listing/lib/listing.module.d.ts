export declare class ListingModule1 {
}
