import { OnInit } from '@angular/core';
export declare class ListingSubcategoryComponent implements OnInit {
    SubsCatListConfig: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}
