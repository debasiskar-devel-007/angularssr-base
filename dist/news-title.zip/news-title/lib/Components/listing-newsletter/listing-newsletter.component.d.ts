import { OnInit } from '@angular/core';
export declare class ListingNewsletterComponent implements OnInit {
    newsLetterListConfig: any;
    loader: boolean;
    constructor();
    ngOnInit(): void;
    config: any;
}
