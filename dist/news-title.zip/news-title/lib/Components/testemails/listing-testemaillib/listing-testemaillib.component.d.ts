import { OnInit } from '@angular/core';
export declare class ListingTestemaillibComponent implements OnInit {
    senderConfigForm: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}
