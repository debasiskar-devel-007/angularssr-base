import { OnInit } from '@angular/core';
export declare class ListingNewsletterlibComponent implements OnInit {
    newsConfigForm: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}
