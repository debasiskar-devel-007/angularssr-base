export declare class NewsTitleService {
    constructor();
}
