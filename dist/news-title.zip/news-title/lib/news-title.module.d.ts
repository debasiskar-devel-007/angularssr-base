export declare class NewsTitleModule {
}
