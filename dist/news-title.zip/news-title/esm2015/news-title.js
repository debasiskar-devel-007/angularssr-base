/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { NewsTitleService, NewsTitleComponent, modalData, NewsTitleModule } from './public-api';
export { ApiService as ɵa } from './lib/api.service';
export { DemoMaterialModule as ɵb } from './lib/material-module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmV3cy10aXRsZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25ld3MtdGl0bGUvIiwic291cmNlcyI6WyJuZXdzLXRpdGxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxpRkFBYyxjQUFjLENBQUM7QUFFN0IsT0FBTyxFQUFDLFVBQVUsSUFBSSxFQUFFLEVBQUMsTUFBTSxtQkFBbUIsQ0FBQztBQUNuRCxPQUFPLEVBQUMsa0JBQWtCLElBQUksRUFBRSxFQUFDLE1BQU0sdUJBQXVCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEdlbmVyYXRlZCBidW5kbGUgaW5kZXguIERvIG5vdCBlZGl0LlxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vcHVibGljLWFwaSc7XG5cbmV4cG9ydCB7QXBpU2VydmljZSBhcyDJtWF9IGZyb20gJy4vbGliL2FwaS5zZXJ2aWNlJztcbmV4cG9ydCB7RGVtb01hdGVyaWFsTW9kdWxlIGFzIMm1Yn0gZnJvbSAnLi9saWIvbWF0ZXJpYWwtbW9kdWxlJzsiXX0=