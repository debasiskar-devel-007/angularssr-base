/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of news-title
 */
export { NewsTitleService } from './lib/news-title.service';
export { NewsTitleComponent, modalData } from './lib/news-title.component';
export { NewsTitleModule } from './lib/news-title.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25ld3MtdGl0bGUvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxpQ0FBYywwQkFBMEIsQ0FBQztBQUN6Qyw4Q0FBYyw0QkFBNEIsQ0FBQztBQUMzQyxnQ0FBYyx5QkFBeUIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgbmV3cy10aXRsZVxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vbGliL25ld3MtdGl0bGUuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uZXdzLXRpdGxlLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uZXdzLXRpdGxlLm1vZHVsZSc7XG4iXX0=