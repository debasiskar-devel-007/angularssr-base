export declare class LoginService {
    constructor();
}
