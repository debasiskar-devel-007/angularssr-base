import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-newsletter',
  templateUrl: './add-edit-newsletter.component.html',
  styleUrls: ['./add-edit-newsletter.component.css']
})
export class AddEditNewsletterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
