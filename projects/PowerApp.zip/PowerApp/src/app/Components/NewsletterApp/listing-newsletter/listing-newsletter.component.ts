import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listing-newsletter',
  templateUrl: './listing-newsletter.component.html',
  styleUrls: ['./listing-newsletter.component.css']
})
export class ListingNewsletterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
