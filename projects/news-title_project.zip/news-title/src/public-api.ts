/*
 * Public API Surface of news-title
 */

export * from './lib/news-title.service';
export * from './lib/news-title.component';
export * from './lib/news-title.module';
